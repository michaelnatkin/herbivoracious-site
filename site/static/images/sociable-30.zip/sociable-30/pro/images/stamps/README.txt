                                __      _ _                   _   
                               / _|    | (_)                 | |  
 _ __ ___   __ _ _ __ ___ ___ | |_ ___ | |_  ___   _ __   ___| |_ 
| '_ ` _ \ / _` | '__/ __/ _ \|  _/ _ \| | |/ _ \ | '_ \ / _ \ __|
| | | | | | (_| | | | (_| (_) | || (_) | | | (_) || | | |  __/ |_ 
|_| |_| |_|\__,_|_|  \___\___/|_| \___/|_|_|\___(_)_| |_|\___|\__|
==================================================================
Social Poststamps - ICON PACK
==================================================================
DESIGNER:                Marco Kuiper
WEBSITE:                 http://www.marcofolio.net/
COUNTRY:                 The Netherlands
COPYRIGHT:               None, but a link to my site would be nice
==================================================================
   This icon pack has been created for Marcofolio.net.
   The package contains the following icons:
   - Delicious
   - Designbump (and grey version)
   - Designfloat (and grey version)
   - Digg
   - FlickR (and grey version)
   - GMail (and grey version)
   - Google (and grey version)
   - PayPal (and grey version)
   - Reddit (and grey version)
   - RSS (and grey version)
   - StumbleUpon (and grey version)
   - Technorati (and grey version)
   - Twitter
   
   In the following formats:
   - 32x32 px
   - 64x64 px
   - 128x128 px
   
   Enjoy and I hope you put them to good use!
==================================================================