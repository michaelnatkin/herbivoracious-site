<form method="post" action="http://www.jumpx.com/listmail/signup.php">

<p align="center">Sign up below to receive a short email each time a new blog entry is posted:</p>

<input type="hidden" name="list" value="1" />
<label>First Name: <input type="text" id="fname" name="fname" size="10" class="firstname" /></label><br />
<label>Email: <input type="text" name="email" class="email" /></label><br />

<div align="center" style="text-align:center"><input type="submit" name="sup" value="Send Announcements!" style="font-size:13px; font-weight:bold;" /></div>
</form>
