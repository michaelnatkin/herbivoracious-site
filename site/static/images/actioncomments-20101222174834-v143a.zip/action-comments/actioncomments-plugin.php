<?php

/* 
 * Plugin Name:   Action Comments
 * Version:       1.4.3a
 * Plugin URI:    http://www.actioncomments.com
 * Description:   Build your e-mail opt-in list using blog comments!  <a href="options-general.php?page=action-comments/actioncomments-plugin.php">Configuration Page.</a>
 * Author:        Robert Plank
 * Author URI:    http://www.robertplank.com
 */

if (!defined('WP_CONTENT_URL')) {
   define('WP_CONTENT_URL', get_option('siteurl') . '/wp-content');
}

define('ACTIONCOMMENTS_URL', WP_CONTENT_URL . "/plugins/" . basename(dirname(__FILE__)));

if (!function_exists("javaScriptSafe")) {
// Output text in a format safe to stick in a JavaScript variable
function javaScriptSafe($input) {
   $input = preg_replace("/\r?\n/si", "\\n", $input);
   $input = preg_replace("/'/", "\'", $input); // Escape slashes
   return $input;
}
}

class ActionCommentsWP {
   var $prompt, $code;
   var $emailfield, $namefield;

   var $counter;

   function ActionCommentsWP() {
      // Upgrade options from version 1.1 and earlier
      if (get_option("actioncomments_prompt")) {
         $settings = get_option("actioncomments_settings");

         if (!is_array($settings)) { $settings = array(); }
         if (!isset($settings[0])) { $settings[0] = array(); }

         $settings[0]["prompt"] = get_option("actioncomments_prompt");
         $settings[0]["delivery"] = get_option("actioncomments_delivery");
         $settings[0]["code"] = get_option("actioncomments_code");
         $settings[0]["namefield"] = get_option("actioncomments_namefield");
         $settings[0]["emailfield"] = get_option("actioncomments_emailfield");

         update_option("actioncomments_settings", $settings);
         delete_option("actioncomments_prompt");
         delete_option("actioncomments_delivery");
         delete_option("actioncomments_code");
         delete_option("actioncomments_namefield");
         delete_option("actioncomments_emailfield");
      }
   }

   function adminInit() {
      if (function_exists('register_setting')) {
         register_setting('actioncomments-group', "actioncomments_settings", '' );
         register_setting('actioncomments-group', "actioncomments_category", '' );
         register_setting('actioncomments-group', "actioncomments_affiliate", '' );
      }
   }

   function scripts() {
      wp_enqueue_script('jquery');
   }

   function settings($postID) {
      if (!is_int($postID)) { $category = $postID; }
      else {
         $the_category = get_the_category($postID);
         $category = $the_category[0]->cat_ID;
      }

      $settings = get_option("actioncomments_settings");
      $postSettings = get_post_meta($postID, 'actioncomments', true);

      if (is_array($settings)) {
         foreach ($settings as $key => $value) {
            if (empty($value)) { unset($settings[$key]); }
         }
      }

      if (is_array($postSettings)) {
         foreach ($postSettings as $key => $value) {
            if (empty($value)) { unset($postSettings[$key]); }
         }
      }

      if (isset($postSettings["code"])) { $code = $postSettings["code"]; }
      elseif (isset($settings[$category]["code"])) { $code = $settings[$category]["code"]; }
      elseif (isset($settings[0]["code"])) { $code = $settings[0]["code"]; }
      else { $code = ""; }

      if (isset($postSettings["prompt"])) { $prompt = $postSettings["prompt"]; }
      elseif (isset($settings[$category]["prompt"])) { $prompt = $settings[$category]["prompt"]; }
      elseif (isset($settings[0]["prompt"])) { $prompt = $settings[0]["prompt"]; }
      else { $prompt = ""; }

      if (!$prompt || empty($prompt)) { $prompt = "Subscribe to blog updates, news and more?"; }

      if (isset($postSettings["emailfield"])) { $emailfield = $postSettings["emailfield"]; }
      elseif (isset($settings[$category]["emailfield"])) { $emailfield = $settings[$category]["emailfield"]; }
      elseif (isset($settings[0]["emailfield"])) { $emailfield = $settings[0]["emailfield"]; }
      else { $emailfield = ""; }

      if (isset($postSettings["namefield"])) { $namefield = $postSettings["namefield"]; }
      elseif (isset($settings[$category]["namefield"])) { $namefield = $settings[$category]["namefield"]; }
      elseif (isset($settings[0]["namefield"])) { $namefield = $settings[0]["namefield"]; }
      else { $namefield = ""; }

      if (isset($postSettings["lastnamefield"])) { $lastnamefield = $postSettings["lastnamefield"]; }
      elseif (isset($settings[$category]["lastnamefield"])) { $lastnamefield = $settings[$category]["lastnamefield"]; }
      elseif (isset($settings[0]["lastnamefield"])) { $lastnamefield = $settings[0]["lastnamefield"]; }
      else { $lastnamefield = ""; }

      if (isset($postSettings["redirect"])) { $redirect = $postSettings["redirect"]; }
      elseif (isset($settings[$category]["redirect"])) { $redirect = $settings[$category]["redirect"]; }
      elseif (isset($settings[0]["redirect"])) { $redirect = $settings[0]["redirect"]; }
      else { $redirect = ""; }

      if (isset($postSettings["delivery"])) { $delivery = $postSettings["delivery"]; }
      elseif (isset($settings[$category]["delivery"])) { $delivery = $settings[$category]["delivery"]; }
      elseif (isset($settings[0]["delivery"])) { $delivery = $settings[0]["delivery"]; }
      else { $delivery = "checkbox"; }
      
      if (isset($postSettings["target"])) { $target = $postSettings["target"]; }
      elseif (isset($settings[$category]["target"])) { $target = $settings[$category]["target"]; }
      elseif (isset($settings[0]["target"])) { $target = $settings[0]["target"]; }
      else { $target = ""; }

      return array(
         "code" => $code,
         "prompt" => $prompt,
         "emailfield" => $emailfield,
         "namefield" => $namefield,
         "lastnamefield" => $lastnamefield,
         "redirect" => $redirect,
         "delivery" => $delivery,
         "category" => $category,
         "target" => $target
      );
   }

   function label() {
      global $post;

      if (!isset($post->ID)) { return; }

      extract($this->settings($post->ID));

      if (isset($_COOKIE["firstname"])) {
         return;
      }

      $affiliate = get_option("actioncomments_affiliate");

      if (!$delivery) { $delivery = "checkbox"; }

      if ($delivery == "checkbox") {
         // Checkbox
         $label = '<label><input type="checkbox" id="actioncomments-enable" checked="checked" style="width:20px; background-color:transparent !important; border:none !important;" /> ' . $prompt . '</label><br />';
      }
      elseif ($delivery == "uncheckbox") {
         // Checkbox
         $label = '<label><input type="checkbox" id="actioncomments-enable" style="width:20px; background-color:transparent !important; border:none !important;" /> ' . $prompt . '</label><br />';
      }
      elseif ($delivery == "silent") {
         $label = $prompt . '<br />';
      }
      else {
         return;
      }

      if ($affiliate) {
         $label .= ' <small><a target="_blank" href="http://' . $affiliate . '.actioncomments.com">(Powered by Action Comments)</a></small>';
      }

      // before entire form: commentform
      // before submit button: submit
      // after email field: email

      ?>
      <script type="text/javascript">
      <!--
         jQuery("#addcommentbutton, #submit").css({clear:"both"}).before('<?php echo javascriptSafe($label); ?>');
      // -->
      </script>
      <?php
   }

   function activate() {
      global $post;

      if (!isset($post->ID)) { return; }

      //print_r($current_user);

      extract($this->settings($post->ID));

      /* subscribe form */
      echo '<div id="actioncomments-form" style="display:none">' . "\n";
      echo $code;
      echo '</div>' . "\n\n";

      /* JavaScript includes */
      //if (!class_exists("ActionCommentsWP")) {
         echo '<script type="text/javascript" src="' . WP_CONTENT_URL . '/plugins/action-comments/actioncomments.php"></script>' . "\n";
      //}
      echo '<script type="text/javascript">' . "\n";
      //echo '<!--' . "\n";

      if ($delivery == "disabled") {
         // Disabled
         echo 'MultiOptin.enable = false;' . "\n";
      }
      elseif ($delivery == "checkbox" || $delivery == "uncheckbox") {
         // Checkbox
         //echo 'alert(document.getElementById("actioncomments-enable"));' . "\n";

         echo 'if (document.getElementById("actioncomments-enable")) {' . "\n";
         echo '   MultiOptin.enable = function() {' . "\n";
         echo '      return (document.getElementById("actioncomments-enable").checked) ? true : false;' . "\n";
         echo '   };' . "\n";
         echo '}' . "\n\n";
      }
      elseif ($delivery == "alert") {
         // Alert
         echo 'MultiOptin.enable = function() { return confirm("' . stripslashes(addslashes($prompt)) . '"); };' . "\n";
      }
      elseif ($delivery == "silent") {
         // Silent
         echo 'MultiOptin.enable = true;' . "\n";
      }

      // Apply CSS grouping
      if (!empty($namefield) && !empty($emailfield)) {
         //echo "var firstForm = document.getElementById('actioncomments-form').getElementsByTagName('FORM')[0];\n";
         //echo "var firstForm = jQuery('#actioncomments-form').find('[name=category2]').attr('name');\n";

         if (!empty($target)) {
            echo 'jQuery("#actioncomments-form").find("form").each(function() { jQuery(this).attr("target", "' . $target . '"); });' . "\n";
         }

         echo "jQuery('#actioncomments-form').find('[name=$namefield]').addClass('firstname');\n";
         echo "jQuery('#actioncomments-form').find('[name=$emailfield]').addClass('email');\n";

         if (!empty($lastnamefield)) {
            echo "jQuery('#actioncomments-form').find('[name=$lastnamefield]').addClass('lastname');\n";
         }

         echo 'MultiOptin.init("actioncomments-form", "email", "author");' . "\n";
      }

      //echo '/' . '/-->' . "\n";
      echo '</script>' . "\n\n";
   }

   function clear() {
      // If saving plugin settings, clear cookies
      if (isset($_POST["actioncomments_prompt"])) {
         setcookie("firstname", "", time()-3600, "/");
      }
   }

   function setupMenu() {
      if (function_exists("add_meta_box")) {
         // Add meta box
         add_meta_box('actioncomments-meta', 'Action Comments', array(&$this, "meta"), "post");
         add_meta_box('actioncomments-meta', 'Action Comments', array(&$this, "meta"), "page");
      }

      if (isset($_POST["actioncomments_code"]) && !isset($_POST["actioncomments_meta"])) {
         $settings = get_option("actioncomments_settings");
         //$category = intval($_POST["actioncomments_savecategory"]);
         $category = $_POST["actioncomments_savecategory"];

         $code = stripslashes($_POST["actioncomments_code"]);
         $prompt = stripslashes($_POST["actioncomments_prompt"]);
         $namefield = stripslashes($_POST["actioncomments_namefield"]);
         $lastnamefield = stripslashes($_POST["actioncomments_lastnamefield"]);
         $emailfield = stripslashes($_POST["actioncomments_emailfield"]);
         $redirect = stripslashes($_POST["actioncomments_redirect"]);
         $delivery = stripslashes($_POST["actioncomments_delivery"]);

         if (isset($_POST["actioncomments_target"])) {
            $settings[$category]["target"] = stripslashes($_POST["actioncomments_target"]);
         }

         if ($redirect) { $settings[$category]["redirect"] = $redirect; }
         else { unset($settings[$category]["redirect"]); }

         //if (!$code && !$prompt) { unset($settings[$category]); }
         //else {
         if (!$code) { unset($settings[$category]["code"]); }
         else {
            $settings[$category]["code"] = $code;
            $settings[$category]["emailfield"] = $emailfield;
            $settings[$category]["namefield"] = $namefield;
            $settings[$category]["lastnamefield"] = $lastnamefield;
         }

         if ($delivery) { $settings[$category]["delivery"] = $delivery; }

         if (!$prompt) { unset($settings[$category]["prompt"]); }
         else { $settings[$category]["prompt"] = $prompt; }

         foreach ($settings as $key => $value) {
            if (empty($value)) { unset($settings[$key]); }
         }

         //if (!$redirect) { unset($settings[$category]["redirect"]); }
         //else { $settings[$category]["redirect"] = $redirect; }
         //}
         update_option("actioncomments_settings", $settings);
      }
      add_options_page('Action Comments Settings', 'Action Comments', 10, __FILE__, array(&$this, 'menu'));
   }

   function meta() {
      global $post;

      if (!isset($post->ID)) { return; }

      $settings = get_post_meta($post->ID, 'actioncomments', true);
      $redirect = "";
      $code = "";
      $namefield = "";
      $lastnamefield = "";
      $emailfield = "";
      $prompt = "";
      $redirect = "";
      $delivery = "";

      echo '<p><b>Hint:</b> Leave these fields blank and the settings for the category (or entire blog) will apply instead.</p>' . "\n";

      echo '<input type="hidden" name="actioncomments_meta" value="true" />' . "\n";
      if (is_array($settings)) { extract($settings); }
      $this->autoresponder($code, $emailfield, $namefield, $lastnamefield, $prompt, $redirect, $delivery);
   }

   function saveSettings($postID, $post=NULL) {
      global $wpdb;

      if ($post == NULL) { return; }
      if (function_exists("wp_is_post_autosave") && wp_is_post_autosave($postID)) { return; }

      if (function_exists("wp_is_post_revision") && ($postRevision = wp_is_post_revision($postID))) {
         $postID = $postRevision;
      }

      if (!function_exists("update_post_meta")) { return; }
      if (!isset($_POST["actioncomments_redirect"]) && !isset($_POST["actioncomments_code"]) && !isset($_POST["actioncomments_prompt"]) && !isset($_POST["actioncomments_delivery"])) { return; }

      $settings = get_post_meta($postID, 'actioncomments');
      if (!is_array($settings)) { $settings = array(); }

      if (isset($_POST["actioncomments_redirect"])) { $settings["redirect"] = stripslashes($_POST["actioncomments_redirect"]); }
      if (isset($_POST["actioncomments_code"])) { $settings["code"] = stripslashes($_POST["actioncomments_code"]); }
      if (isset($_POST["actioncomments_namefield"])) { $settings["namefield"] = stripslashes($_POST["actioncomments_namefield"]); }
      if (isset($_POST["actioncomments_lastnamefield"])) { $settings["namefield"] = stripslashes($_POST["actioncomments_lastnamefield"]); }
      if (isset($_POST["actioncomments_emailfield"])) { $settings["emailfield"] = stripslashes($_POST["actioncomments_emailfield"]); }
      if (isset($_POST["actioncomments_prompt"])) { $settings["prompt"] = stripslashes($_POST["actioncomments_prompt"]); }
      if (isset($_POST["actioncomments_delivery"])) {
         $settings["delivery"] = stripslashes($_POST["actioncomments_delivery"]);
         if ($settings["delivery"] == "inherit") { unset($settings["delivery"]); }
      }

      foreach ($settings as $key => $value) {
         if (empty($value)) { unset($settings[$key]); }
      }

      if (count($settings) > 0) {
         if (!update_post_meta($postID, "actioncomments", $settings)) {
            add_post_meta($postID, "actioncomments", $settings, true);
         }
      }
      else {
         delete_post_meta($postID, "actioncomments");
      }
   	//extract($_POST);
		//$wpdb->query("UPDATE $wpdb->posts SET robotsmeta = '$robotsmeta' WHERE ID = $pID");
   }

   function redirect($url, $comment) {
      global $wpdb;

      $postID = intval($comment->comment_post_ID);

      // Figure out how many comments were left on this post by this person
      $comments = intval($wpdb->get_var("SELECT COUNT(comment_author_email) FROM $wpdb->comments WHERE comment_post_ID = $postID AND comment_author_email = '".$comment->comment_author_email."'"));

      // Only redirect if this is their FIRST comment
      if ($comments != 1) { return $url; }

      $the_category = get_the_category($postID);
      //$category = $the_category[0]->cat_ID;

      $postSettings = get_post_meta($postID, 'actioncomments', true);
      $settings = get_option("actioncomments_settings");

      if (isset($postSettings["redirect"]) && !empty($postSettings["redirect"])) {
         return $postSettings["redirect"];
      }

      foreach($the_category as $category) {
         $catID = $category->cat_ID;

         if (isset($settings[$catID]["redirect"]) && !empty($settings[$catID]["redirect"])) {
            return $settings[$catID]["redirect"];
         }
      }

      
      if (isset($settings[0]["redirect"]) && !empty($settings[0]["redirect"])) {
         return $settings[0]["redirect"];
      }
      return $url;
   }

   function menu() {
      //$category = intval(get_option("actioncomments_category"));
      $category = get_option("actioncomments_category");
      $settings = get_option("actioncomments_settings");

      $code = "";
      $prompt = "";
      $emailfield = "";
      $namefield = "";
      $lastnamefield = "";
      $redirect = "";
      $delivery = "";

      $target = "";

      if (isset($settings[$category])) {
         $settings = $settings[$category];

         if (isset($settings["code"])) { $code = $settings["code"]; }
         else { $code = ""; }

         if (isset($settings["prompt"])) { $prompt = $settings["prompt"]; }
         else { $prompt = ""; }

         if (isset($settings["namefield"])) { $namefield = $settings["namefield"]; }
         else { $namefield = ""; }

         if (isset($settings["lastnamefield"])) { $lastnamefield = $settings["lastnamefield"]; }
         else { $lastnamefield = ""; }

         if (isset($settings["emailfield"])) { $emailfield = $settings["emailfield"]; }
         else { $emailfield = ""; }

         if (isset($settings["redirect"])) { $redirect = $settings["redirect"]; }
         else { $redirect = ""; }

         if (isset($settings["delivery"])) { $delivery = $settings["delivery"]; }
         else { $delivery = ""; }

         if (isset($settings["target"])) { $target = $settings["target"]; }
         else { $target = ""; }
      }

      ?>
      <div class="wrap">
      <h2>Action Comments 1.43A</h2>

      <form method="post" action="options.php">

      <?php wp_nonce_field('update-options'); ?>
      <input type="hidden" name="action" value="update" />
      <input type="hidden" name="page_options" value="actioncomments_category,actioncomments_affiliate" />

      <input type="hidden" name="actioncomments_savecategory" value="<?php echo $category; ?>" />

      <p>Choose a Category: <?php
	  // Get WordPress categories and convert into an array
      $categoryList = get_categories(array("hide_empty" => false));
      $categories = array(0 => "(All Categories)");

      foreach ($categoryList as $categoryId => $categoryItem) {
	      $categories[$categoryItem->cat_ID] = $categoryItem->cat_name;
      }

      $this->dropdown("actioncomments_category", $categories, $category, "document.getElementById('actioncomments_go').click()");

      ?><input type="submit" class="button" value="Go" id="actioncomments_go" /></p>

      <?php
      $this->autoresponder($code, $emailfield, $namefield, $lastnamefield, $prompt, $redirect, $delivery, $category);
      ?>

      <p><B>Submit Form:</B> <?php $this->dropdown("actioncomments_target", array("" => "In the Background", "_blank" => "In a New Window"), $target); ?><br />
      When you're testing to make sure the plugin works, set this to &quot;open in a new window.&quot;<br />
      When your site is live, you'll want to submit &quot;in the background.&quot;</p>

      <p><b>Clickbank ID:</b> <input type="text" name="actioncomments_affiliate" size="15" value="<?php echo get_option("actioncomments_affiliate"); ?>" /><br /> Your <a target="_blank" href="http://simplephp.reseller.hop.clickbank.net">Clickbank affiliate ID</a> if you want to receive 60% commissions for Action Comments.<br />
      (Will open in a new window!)</p></p>

      <p><input type="submit" class="button" value="Save Changes" /></p>

      </form>

      </div>

      <?php
   }

   function autoresponder($code, $emailfield, $namefield, $lastnamefield, $prompt, $redirect, $delivery, $category=0) {
      ?>

      <p><b>HTML Opt-In Code:</b> Paste the cut-n-paste HTML code your autoresponder gave you.  (No JavaScript!)<br />
      (Or: a GotoWebinar URL, i.e. <code>https://www2.gotomeeting.com/register/361463282</code></p>
      <textarea name="actioncomments_code" id="actioncomments_code" class="code" cols="60" rows="10" style="width: 98%; font-size: 12px;" onchange="parseURL(); assignDropdown(true)"><?php echo htmlentities($code); ?></textarea>

      <p><b>Extremely Important:</b> Which is the first name and which is the email field?</p>

      <input type="hidden" name="actioncomments_emailfield_stored" id="actioncomments_emailfield_stored" value="<?php echo $emailfield; ?>" />
      <input type="hidden" name="actioncomments_namefield_stored" id="actioncomments_namefield_stored" value="<?php echo $namefield; ?>" />
      <input type="hidden" name="actioncomments_lastnamefield_stored" id="actioncomments_lastnamefield_stored" value="<?php echo $lastnamefield; ?>" />

      <p>
         <select name="actioncomments_emailfield" id="actioncomments_emailfield"></select>
         <select name="actioncomments_namefield" id="actioncomments_namefield"></select>
         <select name="actioncomments_lastnamefield" id="actioncomments_lastnamefield"></select>
      </p>

      <div id="actioncomments_parse" style="display:none"></div>

      <script type="text/javascript">
      <!--

         function populateDropdown(dropDown, theArray, prefix) {
            var i;
            dropDown.length = 0;

            for (i=0; i<theArray.length; i++) {
               dropDown.options[i] = new Option(prefix + theArray[i], theArray[i]);
            }
         }

         Array.prototype.in_array = function ( obj ) {
            var len = this.length;
            for ( var x = 0 ; x <= len ; x++ ) {
               if ( this[x] == obj ) return true;
            }
            return false;
         }

         function removeChildren(s) {
            while (s.hasChildNodes()) {
               s.removeChild(s.childNodes[0]);
            }
         }

         // Copy the autoresponder code into the parsing form
         var parseForm = document.getElementById('actioncomments_parse');

         var emailField = document.getElementById('actioncomments_emailfield');
         var nameField = document.getElementById('actioncomments_namefield');
         var lastnameField = document.getElementById('actioncomments_lastnamefield');

         function parseURL() {
            var regexp = /^(http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?$/;

            var url = jQuery("#actioncomments_code").val();
            if (!url.match(regexp)) { return; }

            if (url.indexOf("gotomeeting.com") > -1) {
               var webinarID = url.match(/[0-9]{9,}/);

               // Find a 9-plus digit number in the URL...
               if (webinarID) {
                  jQuery("#actioncomments_code").val(
                     '<form action="https://www2.gotomeeting.com/en_US/island/webinar/registration.flow" method="post">\n' +
                     '<input type="hidden" name="Form" value="webinarRegistrationForm">\n' + 
                     '<input type="hidden" name="WebinarKey" value="' + webinarID + '">\n' + 
                     'Firstname: <input type=text name="Name_First">\n' + 
                     'Lastname: <input type=text name="Name_Last">\n' + 
                     'Email: <input type=text name="Email">\n' + 
                     '<input type="submit">\n' + 
                     '</form>'
                  );
               }
            }
         }

         function assignDropdown(change) {
            var change;
            var choices = new Array();

            if (change == undefined) { change = false; }

            jQuery("#actioncomments_parse").html(
               jQuery("#actioncomments_code").val()
            );

            jQuery(parseForm).find("input:text").each(function(i, src) {
               choices[choices.length] = jQuery(src).attr("name");
            });

            populateDropdown(emailField, choices, "Email: ");
            populateDropdown(nameField, choices, "Name: ");

            if (choices.length > 0) {
               choices.unshift("");
            }
            populateDropdown(lastnameField, choices, "Last Name (optional): ");

            //nameField.length = 0;

            //if (document.getElementById('actioncomments_namefield_stored').value == '') {
            if (change || jQuery('#actioncomments_namefield_stored').val() == '') {
               // Guess!
               // EMAIL FIELD
               // GoToWebinar
               if (choices.in_array('Email')) { emailField.value = 'Email'; }

               // Aweber, ListMail Pro
               else if (choices.in_array('email')) { emailField.value = 'email'; }

               // GetResponse
               else if (choices.in_array('SubscriberEmail')) { emailField.value = 'SubscriberEmail'; }
               else if (choices.in_array('subscriber_email')) { emailField.value = 'subscriber_email'; }
               else if (choices.in_array('category3')) { emailField.value = 'category3'; }
               else if (choices.in_array('GRCategory3')) { emailField.value = 'GRCategory3'; }

               // Other
               else if (choices.in_array('Email1')) { emailField.value = 'Email1'; }
               else if (choices.in_array('MailFromAddress')) { emailField.value = 'MailFromAddress'; }
               else if (choices.in_array('SendEmail')) { emailField.value = 'SendEmail'; }
               else { emailField.value = choices[1]; }  

               // FIRSTNAME FIELD
               if (choices.in_array('name')) { nameField.value = 'name'; }
               // ListMail Pro
               else if (choices.in_array('fname')) { nameField.value = 'fname'; }

               // Aweber
               else if (choices.in_array('from')) { nameField.value = 'from'; }

               // GetResponse
               else if (choices.in_array('SubscriberName')) { nameField.value = 'SubscriberName'; }
               else if (choices.in_array('subscriber_name')) { nameField.value = 'subscriber_name'; }
               else if (choices.in_array('category2')) { nameField.value = 'category2'; }
               else if (choices.in_array('GRCategory2')) { nameField.value = 'GRCategory2'; }

               // GoToWebinar
               else if (choices.in_array('Name_First')) { nameField.value = 'Name_First'; }

               // Other
               else if (choices.in_array('SendName')) { nameField.value = 'SendName'; }
               else { nameField.value = choices[0]; }

               // LASTNAME FIELD
               if (choices.in_array('lname')) { lastnameField.value = 'lname'; }
               else if (choices.in_array('Name_Last')) { lastnameField.value = 'Name_Last'; }

            }
            else {
               // Use stored values...
               //emailField.value = document.getElementById('actioncomments_emailfield_stored').value;
               emailField.value = jQuery('#actioncomments_emailfield_stored').val();

               //nameField.value = document.getElementById('actioncomments_namefield_stored').value;
               nameField.value = jQuery('#actioncomments_namefield_stored').val();

               lastnameField.value = jQuery('#actioncomments_lastnamefield_stored').val();
            }
         }

         assignDropdown();
      // -->
      </script>

      <p><b>Prompt:</b> What message will commenters see when you ask them to opt-in to your newsletter?</p>

      <textarea name="actioncomments_prompt" class="code" cols="60" rows="2" style="width: 98%; font-size: 12px;"><?php echo $prompt; ?></textarea>

      <p><b>Redirect URL</b>: Where should visitors be sent after they comment? (leave blank to disable)<br />
      This will only redirect commenters the FIRST time they leave a comment on your post.</p>

      <textarea class="code" name="actioncomments_redirect" rows="2" cols="80" style="width:98%;"><?php echo $redirect; ?></textarea></p>

      <table style="margin-bottom:-50px;">
      <tr>
      <td valign="top">

      <p><b>Delivery Method:</b> How will users see the message?</p>



      <p>This will control how visitors see your message asking them to signup and/or offering them the bribe...</p>

      <?php

      $defaultDeliveries = array(
         "disabled" => "<b>Disabled:</b> Don't capture e-mails.",
         "checkbox" => "<b>Checkbox:</b> Show a checkbox next to the form (already checked).",
         "uncheckbox" => "<b>Unchecked Box:</b> Checkbox next to the form (not checked).",
         "silent" => "<b>Silent:</b> Auto-subscribe to your list without asking (please only use this if you have double optin).",
         "alert" => "<b>Alert:</b> Pop-up a dialog box asking if they want to subscribe.",
         "inherit" => "<b>Inherit:</b> Behave the same way as the rest of the category or blog."
      );

      ?>
      <?php foreach ($defaultDeliveries as $deliveryValue => $deliveryName): ?>
         <label>
         <?php if ($delivery == $deliveryValue) : ?>
            <input type="radio" name="actioncomments_delivery" value="<?php echo $deliveryValue ?>" checked="checked" onclick="document.getElementById('actioncomments_preview').src = '<?php echo ACTIONCOMMENTS_URL; ?>/preview-' + this.value + '.gif';" /><?php echo $deliveryName ?>
         <?php else: ?>
            <input type="radio" name="actioncomments_delivery" value="<?php echo $deliveryValue ?>" onclick="document.getElementById('actioncomments_preview').src = '<?php echo ACTIONCOMMENTS_URL; ?>/preview-' + this.value + '.gif';"  /><?php echo $deliveryName ?>
         <?php endif; ?>
         </label>
         <br />
      <?php endforeach; ?>

      </td>

      <td style="padding:10px;">
      <img src="<?php echo ACTIONCOMMENTS_URL; ?>/preview-<?php echo $delivery; ?>.gif" style="border:none;" id="actioncomments_preview" width="250" height="250" />
      </td>

      </tr>
      </table>
      <?php
   }

   function links($links, $file) {
      if ($file == plugin_basename(__FILE__)) {
         array_unshift($links, "<a href=\"options-general.php?page=$file\">Settings</a>");
      }
      return $links;
   }

   // Function to more easily display dropdown contents
   function dropdown($name, $data, $option=null, $onchange=null) {
      if ($option == null) {
         $option = get_option($name);
      }

      ?>
      <?php if ($onchange == null): ?>
      <select name="<?php echo $name ?>" id="<?php echo $name ?>">
      <?php else: ?>
      <select name="<?php echo $name ?>" id="<?php echo $name ?>" onchange="<?php echo $onchange; ?>">
      <?php endif; ?>
      <?php

      foreach ($data as $value => $text) {
         if ($value == $option) {
            echo '<option value="' . $value . '" selected="selected">' . $text . "</option>\n";
         }
         else {
            echo '<option value="' . $value . '">' . "$text</option>\n";
         }
      }

      ?>
      </select>
      <?php
   }
}

if (function_exists('add_action')) {
   $acwp = new ActionCommentsWP();

   if (is_admin()) {
      add_action('admin_init', array($acwp, 'adminInit'));
      add_action('admin_menu', array($acwp, 'setupMenu'));
      add_filter("plugin_action_links", array($acwp, 'links'), 10, 2);

      // Save settings on meta box
      add_filter("wp_insert_post", array($acwp, 'saveSettings'), 10, 2);
   }
   else {
      add_action('comment_form', array($acwp, 'label'), 4000);
      add_action('wp_footer', array($acwp, 'activate'), 5000);

      add_action('wp_print_scripts', array($acwp, 'scripts'));
      add_action('init', array($acwp, 'clear'));
      add_filter('comment_post_redirect', array($acwp, 'redirect'), 10, 2);
   }
}

?>