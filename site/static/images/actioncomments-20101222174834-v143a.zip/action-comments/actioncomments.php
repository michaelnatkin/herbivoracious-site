<?php

// Action Comments 1.42
// by Robert Plank
// www.ActionComments.com

// Do not distribute - you do NOT have resale rights!
// 60% commission affiliate program: http://www.actioncomments.com/affiliates

require(dirname(__FILE__) . "/actioncomments-packer.php");

if (!function_exists('javascriptCompress')) {
   function javascriptCompress($buffer) {
      $myPacker = new JavaScriptPacker($buffer, 'Normal', true, false);
      return $myPacker->pack();
   }

   ob_start("javascriptCompress");
   header("Content-type:text/javascript");
}

?>
// Cookie functions
var MultiOptinCookie;

if (MultiOptinCookie == undefined) {
   MultiOptinCookie = {

      set : function(name, value, days) {
         var date = new Date();
         if (days != undefined && typeof days == "object") {
            date = days;
         }
         else {

         // Default to a 1 year cookie
         if (days == undefined) { days = 365; }

         // Format date string
         var date = new Date();
         date.setTime(date.getTime() + (days * 86400000));

         }

         // Set cookie name, value, and expiration date
         //window.status = name + "=" + value + "; expires=" + date.toGMTString() + "; path=/";
         document.cookie = name + "=" + value + "; expires=" + date.toGMTString() + "; path=/";
      },

      get : function(name) {
         // Find the cookie's value in the document cookie string
         var results = document.cookie.match(
            new RegExp("(?:^|; )" + name + "=" + "(.*?)(?:$|;)")
         );

         // Return the value if a match was found, undefined otherwise
         if (results && results.length > 1) return results[1];
         return undefined;
      },

      clear : function(name) {
         // Erase a cookie
         MultiOptinCookie.set(name, "", -1);
      }

   };
}

var MultiOptin;

if (MultiOptin == undefined || MultiOptin.version < 1.04) {
MultiOptin = {
   version : 1.04,

   cookies : true,

   confirmPrompt : "",

   enable : true, // connect a function to this for conditional submissions

   formsSubmitted : 0,
   mainForm : null,

   box : null,
   formList : null,

   emailSource : null,
   firstnameSource : null,

   ready : false,
   layered : false,

   init : function(box, emailSource, firstnameSource, lastnameSource) {
      var i;
      var j;
      var blocks;
      var inputs;
      var box;

      if (box == undefined) {
         MultiOptin.box = document.getElementById("actioncomments-form");
      }
      else {
         MultiOptin.box = document.getElementById(box);
      }

      MultiOptin.firstnameSource = firstnameSource;
      MultiOptin.lastnameSource = null;
      if (lastnameSource != undefined && lastnameSource != '' && document.getElementById(lastnameSource)) { MultiOptin.lastnameSource = lastnameSource; }

      MultiOptin.emailSource = emailSource;

      MultiOptin.formList = MultiOptin.box.getElementsByTagName("FORM");

      // Hide the box...
      MultiOptin.box.style.display = "none";

      <?php
      $host = $_SERVER["HTTP_HOST"];
      $refer = $_SERVER["HTTP_REFERER"];
      ?>

      var mydomain = document.domain + "";
      var yourdomain = "<?php echo $host ?>";
      var domainreplace = new RegExp("^www\.", "gi");
      if (mydomain != yourdomain) { return; }

      // Tell all forms to submit inside that invisible iframe...
      for (i=0;i<MultiOptin.formList.length;i++) {

         // Add a frame to the document to "catch" the form submission
         var catcherName = "catcher[" + i + "]";
         document.write('<iframe id="' + catcherName + '" name="' + catcherName + '" width="1" height="1" style="display:none" src="about:blank" onload="MultiOptin.formDone()"></iframe>');

         if (MultiOptin.formList[i].target != "_blank") {
            MultiOptin.formList[i].target = catcherName;
         }
      }

      if (document.getElementById(firstnameSource) && document.getElementById(emailSource)) {

         MultiOptin.mainForm = document.getElementById(MultiOptin.firstnameSource).form;

         MultiOptin.mainForm.onsubmit = function() {
            // First, find out if we should be doing this.
            MultiOptin.ready = true;

            if (typeof MultiOptin.enable == "function" && !MultiOptin.enable()) { return true; }
            else if (!MultiOptin.enable) { return true; }

            // Disable if we've already subscribed
            //else if (MultiOptin.cookies && MultiOptinCookie.get("firstname") != undefined) { return true; }

            MultiOptin.formsSubmitted = 0;

            // Tell all catcher iframes to hit formDone when finished loading
            for (i=0;i<MultiOptin.formList.length;i++) {
               var catcherName = "catcher[" + i + "]";
               document.getElementById(catcherName).onload = MultiOptin.formDone;
            }

            // Copy just the first name over (not the last name)         
            var firstname = document.getElementById(MultiOptin.firstnameSource).value.replace(/ .*$/, '');
            var lastname = document.getElementById(MultiOptin.firstnameSource).value.replace(/^.* /, '');

            if (MultiOptin.lastnameSource != null) {
               if (document.getElementById(MultiOptin.firstnameSource)) {
                  lastname = document.getElementById(MultiOptin.lastnameSource).value.replace(/^.* /, '');
               }
            }

            //if (lastname == '') { lastname = firstname; }
            if (lastname == '' || lastname == firstname) { lastname = '-'; } // 1.42

            // Copy the email address over.
            var email = document.getElementById(MultiOptin.emailSource).value;

            if (firstname != '' && email != '') { MultiOptinCookie.set("firstname", firstname); }

            // Fill in all "firstname" fields
            var nameFields = MultiOptin.getClass("firstname", MultiOptin.box);
            for (i=0;i<nameFields.length;i++) {
               nameFields[i].value = firstname;
            }
            
            // Fill in all "lastname" fields
            var nameFields = MultiOptin.getClass("lastname", MultiOptin.box);
            for (i=0;i<nameFields.length;i++) {
               nameFields[i].value = lastname;
            }

            // Fill in all "email" fields
            var emailFields = MultiOptin.getClass("email", MultiOptin.box);
            for (i=0;i<emailFields.length;i++) {
               emailFields[i].value = email;
            }

            // Submit all the forms
            for (i=0;i<MultiOptin.formList.length;i++) {
               MultiOptin.submitForm(MultiOptin.formList[i]);
            }

            return false;
         };
      }

      // Submit all forms with class "autosubmit"
      for (i=0;i<MultiOptin.formList.length;i++) {
         if (MultiOptin.formList[i].className == "autosubmit") {
            //alert(MultiOptin.formList[i].innerHTML);
            MultiOptin.submitForm(MultiOptin.formList[i]);
         }
      }
   },

   submitForm : function(theForm) {
      if (theForm.submit && theForm.submit.click) { theForm.submit.click(); }
      else if (theForm.submit) { theForm.submit(); }
   },

   formDone : function() {
      if (!MultiOptin.ready) { return false; }
      MultiOptin.formsSubmitted++;

      if (MultiOptin.formsSubmitted >= MultiOptin.formList.length) {
         MultiOptin.mainForm.onsubmit = function() { return true; };

         MultiOptin.submitForm(MultiOptin.mainForm);
      }
   },

   detect : function() {
      if (!MultiOptin.layered) {
         if (!document.getElementById("firstname")) {
            // Tag each input element inside a "multioptin-firstname" under the firstname class
            blocks = MultiOptin.getClass("multioptin-firstname");
            if (blocks && blocks.length > 0) {
               for (i=0; i<blocks.length; i++) {
                  inputs = blocks[i].getElementsByTagName("INPUT");
                  for (j=0; j<inputs.length; j++) { inputs[j].id = "firstname"; }
               }
            }
         }

         if (!document.getElementById("lastname")) {
            blocks = MultiOptin.getClass("multioptin-lastname");
            if (blocks && blocks.length > 0) {
               for (i=0; i<blocks.length; i++) {
                  inputs = blocks[i].getElementsByTagName("INPUT");
                  for (j=0; j<inputs.length; j++) { inputs[j].id = "lastname"; }
               }
            }
         }

         if (!document.getElementById("email")) {
            blocks = MultiOptin.getClass("multioptin-email");
            if (blocks && blocks.length > 0) {
               for (i=0; i<blocks.length; i++) {
                  inputs = blocks[i].getElementsByTagName("INPUT");
                  for (j=0; j<inputs.length; j++) { inputs[j].id = "email"; }
               }
            }
         }

         // Guess the firstname and email fields if they are not defined
         if (!document.getElementById("firstname")) {
            blocks = document.getElementsByTagName("INPUT");
            var nameGuess = '|name|fname|from|SubscriberName|category2|SendName|';
            for (i=0;i<blocks.length;i++) {
               if (nameGuess.indexOf('|' + blocks[i].name + '|') > -1) {
                  blocks[i].id = "firstname";
                  break;
               }
            }
         }

         if (!document.getElementById("lastname")) {
            blocks = document.getElementsByTagName("INPUT");
            var nameGuess = '|lname|lastname|';
            for (i=0;i<blocks.length;i++) {
               if (nameGuess.indexOf('|' + blocks[i].name + '|') > -1) {
                  blocks[i].id = "lastname";
                  break;
               }
            }
         }

         if (!document.getElementById("email")) {
            var emailGuess = '|email|Email1|MailFromAddress|category3|SendEmail';
            for (i=0;i<blocks.length;i++) {
               if (emailGuess.indexOf('|' + blocks[i].name + '|') > -1) {
                  blocks[i].id = "email";
                  break;
               }
            }
         }

         MultiOptin.layered = true;
      }
   },

   getClass : function(clsName, source) {
      if (source == undefined) {
         source = document;
      }

      var retVal = new Array();
      var elements = document.getElementsByTagName("*");

      for (var i=0;i < elements.length;i++) {
         if (elements[i].className.indexOf(" ") >= 0) {
         
            var classes = elements[i].className.split(" ");
            for (var j = 0;j < classes.length;j++) {
               if (classes[j] == clsName) { retVal.push(elements[i]); }
            }
         }
         else if(elements[i].className == clsName) {
            retVal.push(elements[i]);
         }
      }
      return retVal;
   }
};

}