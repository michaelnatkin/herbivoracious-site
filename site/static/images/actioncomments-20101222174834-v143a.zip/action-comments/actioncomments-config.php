<?php

// You don't need to touch this file if you're using Action Comments as a WordPress plugin
$confirmPrompt = "Subscribe to blog updates, news and more?"

?>