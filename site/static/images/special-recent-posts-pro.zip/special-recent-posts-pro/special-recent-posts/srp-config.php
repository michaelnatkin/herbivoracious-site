<?php
/*
| ----------------------------------------------------------
| File        : srp-config.php
| Project     : Special Recent Posts PRO plugin for Wordpress
| Version     : 2.3
| Description : The main config file.
| Author      : Luca Grandicelli
| Author URL  : http://www.lucagrandicelli.com
| Plugin URL  : http://www.lucagrandicelli.com/special-recent-posts-plugin-for-wordpress/
| Copyright (C) 2011  Luca Grandicelli
| ----------------------------------------------------------
*/

/*
| ----------------------------------------------------
|
| GLOBAL ENVIROMENT VALUES
| These are the default plugin settings.
|
| ****************************************************
| ATTENTION: DO NOT CHANGE THESE VALUES HERE.
| ALL THESE VALUES CAN BE CHANGED IN THE WIDGET PANEL
| OR IN THE SETTINGS PAGE.
| ****************************************************
| ----------------------------------------------------
*/

// Defining global default widget values.
global $srp_default_widget_values;

// The global widget options array.
$srp_default_widget_values = array(
	'widget_title'              => 'Special Recent Posts', // Default widget title. 
	'widget_title_link'         => '',                     // Optional widget title URL.
	'widget_css_id'             => '',                     // Optional widget CSS unique ID.
	'widget_additional_classes' => '',                     // Optional additional CSS classes.
	'display_thumbnail'         => 'yes',                  // Display thumbnails?
	'widget_title_hide'         => 'no',                   // Hide widget title?
	'thumbnail_width'           => 100,                    // Default thumbnails width.
	'thumbnail_height'          => 100,                    // Default thumbnails height.
	'thumbnail_link'            => 'yes',                  // Link thumbnails to post?
	'thumbnail_custom_field'    => '',                     // Optional custom field for thumbnails image source.
	'thumbnail_rotation'        => 'no',                   // Default thumbnails rotation option.
	'post_title_above_thumb'    => 'no',                   // Set the post title above the thumbnail.
	'post_type'                 => 'post',                 // Default displayed post types.
	'post_status'               => 'publish',              // Default displayed post status.
	'post_limit'                => 5,                      // Default max number of posts to display.
	'post_title_nolink'         => 'no',                   // Disable post titles link.
	'post_content_type'         => 'content',              // Default post content type.
	'post_content_length'       => '100',                  // Default displayed post content length. 
	'post_content_length_mode'  => 'chars',                // Default displayed post content length mode.
	'post_title_length'         => '100',                  // Default displayed post title length. 
	'post_title_length_mode'    => 'fulltitle',            // Default displayed post title length mode. 
	'post_order'                => 'DESC',                 // Default displayed post order.
	'post_offset'               => 0,                      // Default post offset.
	'post_random'               => 'no',                   // Randomize displayed posts?
	'post_noimage_skip'         => 'no',                   // Skip posts without images?
	'post_link_excerpt'         => 'no',                   // Link the entire post excerpt to post?
	'post_current_hide'         => 'yes',                  // Hide current post from visualization when in single post view?
	'post_content_mode'         => 'titleexcerpt',         // Default layout content mode.
	'post_date'                 => 'yes',                  // Display post date?
	'post_author'               => 'no',                   // Display post author?
	'post_author_url'           => 'yes',                  // Display post author URL link?
	'post_author_prefix'        => 'Published by: ',       // Default post author PREFIX.
	'post_category'             => 'no',                   // Display post categories?
	'post_category_link'        => 'yes',                  // Display post categories URL link?
	'post_category_separator'   => ',',                    // Default post categories separator.
	'post_category_prefix'      => 'Category: ',           // Display post categories PREFIX.
	'post_tags'                 => 'no',                   // Display post tags?
	'post_tags_prefix'          => 'Tags: ',               // Default post tags PREFIX.
	'post_tags_separator'       => ',',                    // Default post tags separator.
	'post_include'              => '',                     // Filter posts by including post IDs.
	'post_include_sub'          => 'no',                   // Include sub-pages when filtering by pages IDs?
	'post_exclude'              => '',                     // Exclude posts from visualization by IDs.
	'post_meta_key'             => '',                     // Filter post by Meta Key.
	'post_meta_value'           => '',                     // Filter post by Meta Value.
	'custom_post_type'          => '',                     // Filter post by Custom Post Type.
	'tags_include'              => '',                     // Filter post by Tags.
	'noposts_text'              => 'No posts available',   // Default 'No posts available' text.
	'allowed_tags'              => '',                     // List of allowed tags to display in the excerpt visualization.
	'string_break'              => '[...]',                // Default string break text.
	'image_string_break'        => '',                     // Path to optional image string break.
	'string_break_link'         => 'yes',                  // Link (image)string break to post?
	'date_format'               => 'F jS, Y',              // Post date format.
	'category_include'          => '',                     // Filter posts by including categories IDs.
	'category_exclude'          => '',                     // Filter posts by excluding categories IDs.
	'category_title'            => 'no',                   // When filtering by caqtegories, switch the widget title to a linked category title.
	'nofollow_links'            => 'no',                   // Add the 'no-follow' attribute to all widget links.
	'layout_mode'               => 'single_column',        // Default layout visualization mode.
	'layout_num_cols'           => '2',                    // Default number of columns when in multi-columns layout mode.
	'shortcode_generator_area'  => '',                     // Value for generated shortcode.
	'phpcode_generator_area'    => ''                      // Value for generated PHP code.
);

// Defining global default plugin values.
global $srp_default_plugin_values;

// The global plugin options array.
$srp_default_plugin_values = array(
	'srp_version'               => SRP_PLUGIN_VERSION,                 // The Special Recent Post current version.
	'srp_global_post_limit'     => 3,                                  // *** DO NOT CHANGE THIS ***.
	'srp_compatibility_mode'    => 'yes',                              // Compatibility Mode Option.
	'srp_noimage_url'           => SRP_PLUGIN_URL . SRP_DEFAULT_THUMB, // Defaul URL to the no-image placeholder.
	'srp_log_errors_screen'     => 'no',
	'srp_disable_theme_css'     => 'no',                               // Disable plugin CSS?
	
	// The widget front-end CSS.
	'srp_theme_css'             => "

/*
| ----------------------------------------
| General Section
| ----------------------------------------
*/

| - ATTENTION IE users: The following rules are only compatible with IE8+
| - Please consider to specify custom CSS rules to support previous IE versions.
| - In order to mantain a minimum compatibnility with IE7, a special CSS file is stored at special-recent-posts/css/css-ie7-fix.css.
| - Feel free to modify this file which is loaded by a conditional statement in the HTML header of the rendered webpage.

/* The Recent Posts Container. */
div.srp-widget-container {
	display : table;
	clear   : both;
}

/* The Widget Title. */
div.srp-widget-container h3.widget-title{
	display       : block;
	margin-bottom : 10px;
}

// The widget title link
a.srp-widget-title-link {}

/* Single post entry box. */
div.srp-widget-singlepost {
	padding       : 0px 0px 10px 0px;
	margin        : 0px 0px 10px 0px;
	border-bottom : 1px solid #CCCCCC;
	clear         : both;
}

/* The single row container and the single column container */
div.srp-single-row, div.srp-widget-column {
	display        : table-cell !important;
	vertical-align : top !important;
	margin         : 0px 0px 0px 0px !important;
	padding        : 0px 10px 0px 0px !important;
	border         : none !important;
}

/* The multi-column class on each post entry */
div.srp-multi-column {}

/* The single-row class on each post entry */
div.srp-single-row {}
/*
| ----------------------------------------
| Thumbnail Section
| ----------------------------------------
*/

/* The thumbnail box. */
div.srp-thumbnail-box {
	display        : table-cell;
	vertical-align : top;
	padding-right  : 10px;
}

/* The thumbnail link. */
a.srp-widget-thmblink {}

/* The thumbnail image. */
img.srp-widget-thmb {}

/*
| ----------------------------------------
| Content Section
| ----------------------------------------
*/

/* The content box. */
div.srp-content-box {
	display        : table-cell;
	vertical-align : top;
}

/* The single post title. */
h4.srp-post-title {
	display: block;
}

/* The single post title link. */
a.srp-post-title-link {}

/* The post excerpt. */
p.srp-widget-excerpt {
	margin: 0px;
}

/* The linked Excerpt */
a.srp-linked-excerpt {}

/* The stringbreak. */
span.srp-widget-stringbreak {}

/* The stringbreak link. */
a.srp-widget-stringbreak-link {}

/* The stringbreak link image. */
a.srp-widget-stringbreak-link-image {}

/* The post date box. */
p.srp-widget-date {
	margin: 0px;
}

/* The post author box. */
p.srp-widget-author {
	margin: 0px;
}

/* The post category box. */
p.srp-widget-category {
	margin: 0px;
}

/* The tags box */
p.srp-widget-tags {
	margin: 0px;
}
"
);
?>