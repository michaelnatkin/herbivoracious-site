<?php
  if(!defined("ABSPATH"))
    die(); 
?>
<div id="codeguard_signup" class="updated fade">
<h2>CodeGuard is almost ready!</h2>
<div id="codeguard_inline_error"></div>
<p><strong>To create an account and begin backing up your site, just tell us your email address. If you already have an account, <a href="admin.php?page=codeguard-admin-menu">enter your information here.</a></strong></p>
<form method="post" action="">
  <input type="text" name="codeguard_signup_email" style="width:200px" value="<?php echo $this->get_suggested_signup_email(); ?>" />
  <input type="submit" value="Go" class="button" id="codeguard-signup-submit" name="">
</form>
<a style="margin-left:25px;" href="admin.php?page=codeguard-admin-menu">Already a CodeGuard user?</a>
</div>

<script type="text/javascript" >
var codeguard_signup_init = function() {
	if(typeof(jQuery) == 'undefined') {
		setTimeout("codeguard_signup_init()", 10);
	} else {
		jQuery(document).ready(function() {
				wp_codeguard.check_for_error_messages('#codeguard_hidden_error', '#codeguard_inline_error');
				});
	}
};
codeguard_signup_init();
</script>
