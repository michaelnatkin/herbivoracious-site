<?php
if(!defined("ABSPATH"))
  die(); 
?>

<div id="codeguard-warning" class="updated fade error">
  <p>
  <strong>ERROR</strong>: Your WordPress site is missing features that are required to use the CodeGuard plugin. Please ask your host to enable openssl support.
  </p>
</div>
