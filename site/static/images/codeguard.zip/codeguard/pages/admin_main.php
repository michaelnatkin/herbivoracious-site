<?php
if(!defined("ABSPATH"))
  die(); 
?>
<div class="wrap">
    <img src="<?php echo $this->codeguard_plugin_image_url(); ?>cglogo_small_nav.png" />
    <div id="codeguard_admin_section">
      <div id="codeguard_inline_error"></div>
<?php

?>
      <h2>Is your site protected?</h2>
      <p>CodeGuard is a time machine for your website!&nbsp;<a target="_blank" href="https://www.codeguard.com">Learn more about CodeGuard.</a></p>
      </div>
      <div id="cgadmin-content">
<?php
if ($this->has_valid_codeguard_tokens()) { 
?>
  <h2>CodeGuard Status</h2>
  <p><img class="codeguard-cgshield" src="http://codeguard.com/images/shield.green.png" style="height:24px;width:24px;"/> Your user credentials are valid!</p>
<?php
if ($this->has_website_id() ) { 
?>
  <p><img class="codeguard-cgshield" src="http://codeguard.com/images/shield.green.png" style="height:24px;width:24px;"/> Your website has been added to CodeGuard!</p>
<?php
  $this->codeguard_dashboard_widget();
} else {
?>
  <p><img src="http://codeguard.com/images/shield.red.png" style="height:24px;width:24px;"/> Your website has not yet been added.</p>
  <form action="" method="post" id="codeguard-add-website-form" style="">
    <input type="hidden" id="codeguard-add-website" name="codeguard-add-website" value="true" />
    <p class="submit"><input type="submit" name="submit" value="Add website" /></p>
  </form>
<?php
  }
} else {
?>
      <h2>Already a CodeGuard user?</h2>
      <p>Enter your CodeGuard key and secret below. Not sure what these are? <a target="_blank" href="https://www.codeguard.com/wordpress">Click here to find your CodeGuard key and secret.</a></p>

    <form action="" method="post" id="codeguard-tokens-form" style="">
      <h3><label for="codeguard-tokens-key">Key<label></h3>
        <p><input id="codeguard-tokens-key" name="codeguard-tokens-key" type="text" size="40" value="<?php echo $this->get_codeguard_api_access_token(); ?>" style="font-family: 'Courier New', Courier, mono; font-size: 1.5em;" /></p>
      <h3><label for="codeguard-tokens-secret">Secret</label></h3>
        <p><input id="codeguard-tokens-secret" name="codeguard-tokens-secret" type="text" size="40" value="<?php echo $this-> get_codeguard_api_access_secret(); ?>" style="font-family: 'Courier New', Courier, mono; font-size: 1.5em;" /></p>
        <p class="submit"><input type="submit" name="submit" value="Update" /></p>
      </form>
<?php
}


?>
    </div>
  </div>
<div class="clear"></div>
<a id="codeguard-plugin-reset" href="javascript:;">CodeGuard Plugin Reset</a>
<script type="text/javascript" >
var codeguard_admin_init = function() {
	if(typeof(jQuery) == 'undefined') {
		setTimeout("codeguard_admin_init()", 10);
	} else {
	jQuery(document).ready(function() {
	  wp_codeguard.check_for_error_messages('#codeguard_hidden_error', '#codeguard_inline_error');
	  // Unfortunately, the Jetpack banner gets positioned right in the middle of our header content, so we have to hide it.
	  jQuery('div#message.updated.jetpack-message.jp-connect').hide();
	  jQuery('#codeguard-plugin-reset').click(function() {
	    if(confirm("Are you sure? This will prevent CodeGuard from backing up your WordPress site.")) {
	      jQuery.post("", {"codeguard-plugin-reset" : true}, function() { location.reload() });
	    }
	  });
	});
	}
};
codeguard_admin_init();
</script>
